# Cambios Panther VIP

- Nombre visible: Panther VIP (se elimina el nombre Calculadora).
- La pantalla de acceso usa la imagen azul/cruz enviada como fondo a pantalla completa.
- La key `prueba-2026` abre el menú de Patches con rol de usuario (no administrador).
- La key de prueba se valida localmente en el cliente y no requiere el servidor; no usar como autenticación segura en una distribución pública.
- El proyecto debe compilarse en macOS con Xcode mediante `.github/workflows/build-ipa.yml`. Este entorno no dispone de Xcode/macOS, por lo que no es posible generar ni firmar aquí un IPA nuevo.
