Fondos nuevos de Ghostface azul sin barra de estado, elementos de inicio de sesion reales en SwiftUI, Telegram en login y menu, barra de estado oculta, animacion suave conservada. No se modifican paquetes offline ni voces. Requiere prueba de compilacion Xcode.


## Ajustes visuales solicitados — SENSI OG
- Se quitaron el encabezado y el subtítulo de paquetes.
- Pestañas AIM y HOLO ARMA; HOLO ARMA muestra EN CREACIÓN.
- Los nombres visibles de los cuatro controles AIM cambiaron sin modificar sus identificadores internos ni las llamadas de activación.
- Se ocultó la línea que mostraba “Pacote .3105”.
- El botón Cerrar sesión se sustituyó por un enlace a Telegram SENSIOGCUBA.
- Se aumentó ligeramente el brillo y la saturación del fondo sin recortarlo.
